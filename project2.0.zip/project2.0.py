#topper kise ke sage nahi hote
import logging
def add(x,y):
    addc=x+y
    return addc
def sub(x,y):
    subc=x-y
    return subc
def mul(x,y):
    mulc=x*y
    return mulc
def div(x,y):
    divc=x/y
    return divc
def pwr(x,y):
    powc=x**y
    return powc
def mod(x,y):
    modc=x%y
    return modc
def bas(x,y):
    basc=x//y
    return basc
def fac(x):
    facn=1
    facc=1
    while facn<=x:
        facc=facc*facn
        facn+=1
    return facc
def srt(a,b,c):
    import cmath
    d = (b**2) - (4*a*c)
    sol1 = (-b-cmath.sqrt(d))/(2*a)
    sol2 = (-b+cmath.sqrt(d))/(2*a)
    return(sol1,sol2)
#--------------------------------------------------------------------------------------------------------------------------
print("*"*75)
print("(✪‿✪)ノ Hi, i am Silvia, your all in one assistant")
name=input("firstly,tell me your name=")
powd=input ("enter your password=")
print("just joking there is no password")
#initaial statement for name and password
#--------------------------------------------------------------------------------------------------------------------------
proval="c"
while proval=="c":
    print("*"*75)
    print(name,",welcome back to the main menu  (͡• ͜໒ ͡• )")
    prored=int(input("please select what do you want to do= '1' for homework help,'2' for games,'3'for chat bot, '4' for calender and 5 for to do list:"))
    #the main menu for enyering the catagories
    #_________________________________________________________________________________________________________________________
    #)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
    #_________________________________________________________________________________________________________________________
    if prored==1:
        print("you have entered the homework assistance section...")
        hwred=int(input("enter 1 for calculator , 2 for quadratic equation , 3 for lcm, 4 for hcf and 5 for interest calculator:"))
        #reached the homework section
        #___________________________________________________________________________________________________________________________
        if hwred==1:
            import math

            i = 1
            if i == 1:
                def add(x, y):
                    b = (x + y)
                    return (b)


                def sub(x, y):
                    b = (x - y)
                    return (b)


                def mul(x, y):
                    b = (x * y)
                    return (b)


                def div(x, y):
                    b = (x / y)
                    return (b)


                def pow(x, y):
                    b = (x ** y)
                    return (b)


                def root(x, y):
                    b = (x ** (1 / y))
                    return (b)


                def mod(x, y):
                    b = (x % y)
                    return (b)


                def fld(x, y):
                    b = (x // y)
                    return (b)


                def sin(x):
                    b = (math.sin(x))
                    return (b)


                def cos(x):
                    b = (math.cos(x))
                    return (b)


                def tan(x):
                    b = (math.tan(x))
                    return (b)


                def cosec(x):
                    b = (1 / math.sin(x))
                    return (b)


                def sec(x):
                    b = (1 / math.cos(x))
                    return (b)


                def cot(x):
                    b = (1 / math.tan(x))
                    return (b)


                def fact(x):
                    d = 1
                    while x > 1:
                        d *= x
                        x -= 1
                    b = (d)
                    return (b)


                def ln(x):
                    b = (math.log(x))
                    return (b)


                def log(x):
                    b = (math.log(x, 10))
                    return (b)


                def logy(x, y):
                    b = (math.log(x, y))
                    return (b)

            print(
                '''+ for addition
            - for subtraction
            * for multiplication
            / for division
            ^ for power
            r for root
            % for modulus
            // for floor division 
            sin for sin (trig) 
            cos for cos (trig) 
            tan for tan (trig)
            cosec for cosec(trig) 
            sec for sec(trig) 
            cot for cot(trig)
            ! for factorial
            ln for ln (natural log)
            log for log (log base 10)
            logy for log with base y''')

            print("\n")

            print(
                '''For any function where only one input is required you need to put zero (or any number) as the second number.
            The first number will be used for calculations''')

            print("\n")

            n = "y"
            c = "n"

            while n == "y":
                a = input("Enter symbol for the function you want calculated:- ")
                if c == "n":
                    x = float(input("Enter first number:- "))
                elif c == "y":
                    x = b
                y = float(input("Enter second number:- "))

                if a == "+":
                    b = add(x, y)
                    print(b)
                elif a == "-":
                    b = sub(x, y)
                    print(b)
                elif a == "*":
                    b = mul(x, y)
                    print(b)
                elif a == "/":
                    b = div(x, y)
                    print(b)
                elif a == "^":
                    b = pow(x, y)
                    print(b)
                elif a == "r":
                    b = root(x, y)
                    print(b)
                elif a == "%":
                    b = mod(x, y)
                    print(b)
                elif a == "//":
                    b = fld(x, y)
                    print(b)
                elif a == "sin":
                    b = sin(x)
                    print(b)
                elif a == "cos":
                    b = cos(x)
                    print(b)
                elif a == "tan":
                    b = tan(x)
                    print(b)
                elif a == "cosec":
                    b = cosec(x)
                    print(b)
                elif a == "sec":
                    b = sec(x)
                    print(b)
                elif a == "cot":
                    b = cot(x)
                    print(b)
                elif a == "!":
                    b = fact(x)
                    print(b)
                elif a == "ln":
                    b = ln(x)
                    print(b)
                elif a == "log":
                    b = log(x)
                    print(b)
                elif a == "logy":
                    b = logy(x, y)
                    print(b)
                else:
                    print("Enter valid symbol")

                c = input("Do you want to use your previous result, write y for yes or n for no:- ")
                if c != "n" and c != "y":
                    print("Enter valid argument")
                elif c == "n" or c == "y":
                    continue

                n = input("Do you want to continue, write y for yes or n for no:- ")
                if n != "n" and n != "y":
                    print("Enter valid argument")
                elif n == "n" or n == "y":
                    continue

            if n == "no":
                print("Thank you for using our calculator")
            #___________________________________________________________________________________________________________________
        elif hwred==2 :

            #-------------------------------------------------------------------------------
            #the code for the square root calculator in homework
            srtval="c"
            while srtval=="c":
                print("*"*75)   
                print("quadratic equation solution finderinator is ready to start.......")
                a=int(input("enter the value of the coeffecient of x^2"))
                b=int(input("enter the value of the coeffecient of x"))
                c=int(input("enter the value of the constant"))
                print("the solutions of the quadratic equation(",a,")x^2 +(",b,")x + (",c,") are =",srt(a,b,c))
            #-------------------------------------------------------------------------------
            #for lcm and hcf in calculator
                srtval=input("if you wish to do some more calculations input 'c' or if you wish to go back to main menu input'b'")
            #________________________________________________________________________________________________________________________
        elif hwred==3 :
            def compute_lcm(x, y):

               if x > y:
                   greater = x
               else:
                   greater = y

               while(True):
                   if((greater % x == 0) and (greater % y == 0)):
                       lcm = greater
                       break
                   greater += 1

               return lcm

            num1 =int(input("enter the first no."))
            num2 =int(input("enter the second no."))

            print("The L.C.M. is", compute_lcm(num1, num2))
            #_______________________________________________________________________________________________________________________
        elif hwred==4:
            def compute_hcf(x, y):
                if x > y:
                    smaller = y
                else:
                    smaller = x
                for i in range(1, smaller+1):
                    if((x % i == 0) and (y % i == 0)):
                        hcf = i 
                return hcf

            num1 =int(input("enter the first no."))
            num2 =int(input("enter the second no."))

            print("The H.C.F. is", compute_hcf(num1, num2))
        elif hwred==5:
            print("Enter the value of r in decimals.")
            b = input("Is your time in months, yes (y) or no (n):- ")
            print("")

            a = input('''Do you want to calculate simple interest or complex interest,
            Enter S.I or C.I:- ''')

            if a == "S.I" and b == "n":
                p = float(input("Enter principal amount:- "))
                r = float(input("Enter rate of interest:- "))
                t = float(input("Enter time in years:- "))
                si = (p * r * t) / 100
                print(si)


            if a == "C.I" and b == "n":
                p = float(input("Enter principal amount:- "))
                r = float(input("Enter rate of interest:- "))
                n = float(input("Enter number of times interest applied per time period:- "))
                t = float(input("Enter time in years:- "))
                x = 1 + r/n
                y = p * x
                z = n * t
                ci = y ** z
                print(ci)

            if a == "S.I" and b == "y":
                p = float(input("Enter principal amount:- "))
                r = float(input("Enter rate of interest:- "))
                c = float(input("Enter time in months:- "))
                t = c / 12
                si = (p * r * t) / 100
                print(si)

            if a == "C.I" and b == "y":
                p = float(input("Enter principal amount:- "))
                r = float(input("Enter rate of interest:- "))
                n = float(input("Enter number of times interest applied per time period:- "))
                c = float(input("Enter time in years:- "))
                t = c / 12
                x = 1 + r/n
                y = p * x
                z = n * t
                ci = y ** z
                print(ci)
            #________________________________________________________________________________________________________________________
            #)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
            #________________________________________________________________________________________________________________________
    elif prored==2:
        print(name,"you have entered the arcade")
        gmred=int(input("enter 1 for hangman , 2 for snake, 3 for rockpaper sissor, 4 for card game, 5 for chess, 6 for tic tac toe and 7 for minesweeper"))
        #______________________________________________________________________________________________________________________________
        if gmred==1 :
            import random
            import sys


            wordList = ["lion", "umbrella", "window", "computer", "glass", "juice", "chair", "desktop",
             "laptop", "dog", "cat", "lemon", "cabel", "mirror", "hat","table"]

            guess_word = []
            secretWord = random.choice(wordList)
            length_word = len(secretWord)
            alphabet = "abcdefghijklmnopqrstuvwxyz"
            letter_storage = []



            def beginning():
                print("Hello Mate!\n")

                while True:
                    name = input("Please enter Your name\n").strip()

                    if name == '':
                        print("You can't do that! No blank lines")
                    else:
                        break

            beginning()



            def newFunc():
                print("Well, that's perfect moment to play some Hangman!\n")

                while True:
                    gameChoice = input("Would You?\n").upper()

                    if gameChoice == "YES" or gameChoice == "Y":
                        break
                    elif gameChoice == "NO" or gameChoice == "N":
                        sys.exit("That's a shame! Have a nice day")
                    else:
                        print("Please Answer only Yes or No")
                        continue

            newFunc()



            def change():

                for character in secretWord:
                    guess_word.append("-")

                print("Ok, so the word You need to guess has", length_word, "characters")

                print("Be aware that You can enter only 1 letter from a-z\n\n")

                print(guess_word)



            def guessing():
                guess_taken = 1

                while guess_taken < 10:


                    guess = input("Pick a letter\n").lower()

                    if not guess in alphabet: 
                        print("Enter a letter from a-z alphabet")
                    elif guess in letter_storage: 
                        print("You have already guessed that letter!")
                    else: 

                        letter_storage.append(guess)
                        if guess in secretWord:
                            print("You guessed correctly!")
                            for x in range(0, length_word): 
                                if secretWord[x] == guess:
                                    guess_word[x] = guess
                                    print(guess_word)

                            if not '-' in guess_word:
                                print("You won!")
                                break
                        else:
                            print("The letter is not in the word. Try Again!")
                            guess_taken += 1
                            if guess_taken == 10:
                                print(" Sorry Mate, You lost :<! The secret word was",         secretWord)


            change()
            guessing()

            print("Game Over")
            #______________________________________________________________________________________________________________________
        elif gmred==2:
            import random
            import turtle
            import time


            class Square:
                def __init__(self, x, y):
                    self.x = x
                    self.y = y

                def drawself(self, turtle):
                    turtle.goto(self.x - 9, self.y - 9)
                    turtle.begin_fill()
                    for i in range(4):
                        turtle.forward(18)
                        turtle.left(90)
                    turtle.end_fill()


            class Food:
                def __init__(self, x, y):
                    self.x = x
                    self.y = y
                    self.state = "ON"

                def changelocation(self):
                    self.x = random.randint(0, 20)*20 - 200
                    self.y = random.randint(0, 20)*20 - 200

                def drawself(self, turtle):
                    if self.state == "ON":
                        turtle.goto(self.x - 9, self.y - 9)
                        turtle.begin_fill()
                        for i in range(4):
                            turtle.forward(18)
                            turtle.left(90)
                        turtle.end_fill()

                def changestate(self):
                    self.state = "OFF" if self.state == "ON" else "ON"


            class Snake:
                def __init__(self):
                    self.headposition = [20, 0]
                    self.body = [Square(-20, 0), Square(0, 0), Square(20, 0)]
                    self.nextX = 1 
                    self.nextY = 0
                    self.crashed = False 
                    self.nextposition = [self.headposition[0] + 20*self.nextX,
                                         self.headposition[1] + 20*self.nextY]


                def moveOneStep(self):
                    if Square(self.nextposition[0], self.nextposition[1]) not in self.body: 
                        
                        self.body.append(Square(self.nextposition[0], self.nextposition[1])) 
                        
                        del self.body[0]
                        self.headposition[0], self.headposition[1] = self.body[-1].x, self.body[-1].y 
                    
                        self.nextposition = [self.headposition[0] + 20*self.nextX,
                                             self.headposition[1] + 20*self.nextY]
                    else:
                        self.crashed = True

                def moveup(self): 
                    self.nextX = 0
                    self.nextY = 1

                def moveleft(self):
                    self.nextX = -1
                    self.nextY = 0

                def moveright(self):
                    self.nextX = 1
                    self.nextY = 0

                def movedown(self):
                    self.nextX = 0
                    self.nextY = -1

                def eatFood(self):
                    
                    self.body.append(Square(self.nextposition[0], self.nextposition[1]))
                    self.headposition[0], self.headposition[1] = self.body[-1].x, self.body[-1].y
                    self.nextposition = [self.headposition[0] + 20*self.nextX,
                                         self.headposition[1] + 20*self.nextY]

                def drawself(self, turtle):
                    for segment in self.body:
                        segment.drawself(turtle)


            class Game:
                def __init__(self):
                    
                    self.screen = turtle.Screen()
                    self.artist = turtle.Turtle()
                    self.artist.up()
                    self.artist.hideturtle()
                    self.snake = Snake()
                    self.food = Food(100, 0)
                    self.counter = 0 
                    self.commandpending = False 

                def nextFrame(self):
                    while True:
                        game.screen.listen()
                        game.screen.onkey(game.snakedown, "Down")
                        game.screen.onkey(game.snakeup, "Up")
                        game.screen.onkey(game.snakeleft, "Left")
                        game.screen.onkey(game.snakeright, "Right")
                        turtle.tracer(0) 
                        self.artist.clear()
                        if self.counter == 5: 
                        
                            if (self.snake.nextposition[0], self.snake.nextposition[1]) == (self.food.x, self.food.y):
                                self.snake.eatFood()
                                self.food.changelocation()
                            else:
                                self.snake.moveOneStep()
                            self.counter = 0
                        else:
                            self.counter += 1
                        self.food.changestate() 
                        self.food.drawself(self.artist) 
                        self.snake.drawself(self.artist)
                        turtle.update()
                        self.commandpending = False
                        time.sleep(0.05)

                def snakeup(self):
                    print("up") 
                    if not self.commandpending: 
                    
                        self.snake.moveup()
                        self.commandpending = True

                def snakedown(self):
                    print("down")
                    if not self.commandpending:
                        self.snake.movedown()
                        self.commandpending = True

                def snakeleft(self):
                    print("left")
                    if not self.commandpending:
                        self.snake.moveleft()
                        self.commandpending = True

                def snakeright(self):
                    print("right")
                    if not self.commandpending:
                        self.snake.moveright()
                        self.commandpending = True


            game = Game()
            game.nextFrame()
            print("game over!")

            game.screen.mainloop()
            #_____________________________________________________________________________________________________________________
        elif gmred==3:
            from random import randint
            t = ["Rock", "Paper", "Scissors"]
            computer = t[randint(0,2)]
            player = False

            while player == False:
                player = input("Rock, Paper, Scissors?")
                if player == computer:
                    print("Tie!")
                elif player == "Rock":
                    if computer == "Paper":
                        print("You lose!", computer, "covers", player)
                    else:
                        print("You win!", player, "smashes", computer)
                elif player == "Paper":
                    if computer == "Scissors":
                        print("You lose!", computer, "cut", player)
                    else:
                        print("You win!", player, "covers", computer)
                elif player == "Scissors":
                    if computer == "Rock":
                        print("You lose...", computer, "smashes", player)
                    else:
                        print("You win!", player, "cut", computer)
                else:
                    print("That's not a valid play. Check your spelling!")
                player = False
                computer = t[randint(0,2)]
                #____________________________________________________________________________________________________________________
        elif gmred==4:
            import random
            from itertools import product
            class Deck():
                suit = ('hearts', 'spades', 'diamond', 'clubs')
                ranks = ('two', 'three', 'four', 'five', 'six', 'seven', 'eight',
                         'nine', 'ten', 'jack', 'queen', 'king', 'ace')
                values = {'two':2, 'three':3, 'four':4, 'five':5, 'six':6, 'seven':7,
                         'eight':8,'nine':9, 'ten':10, 'jack':11,
                         'queen':12, 'king':13, 'ace':1,}
                def __init__(self):
                    self.deck1 = list(product(Deck.suit,Deck.ranks))
                    random.shuffle(self.deck1)
                def draw_card(self):
                    if len(self.deck1) == 0:
                        return 0
                    else:
                        return self.deck1.pop()
                def shuffle_deck(self):
                    random.shuffle(self.deck1)
                def __str__(self):
                    return str(self.deck1)

            class Card(Deck):
                def __init__(self,deck):
                    self.card = deck.draw_card()
                    if self.card == 0:
                        raise Exception('All card Dealt')
                    self.suit = self.card[0]
                    self.rank = self.card[1]
                    self.value = self.values[self.rank]
                def __str__(self):
                    return f'{self.rank} of {self.suit}'
                def getval(self):
                    return self.value  
                
            def sel_val():
                a = int(input('enter your number: \n'))
                if not a in range(1,201):
                    print('enter number in 1 and 200')
                    exit()
                b = random.randint(1,200)
                return a,b

            def game(lst,deck):
                lst.append(Card(deck))
                return lst[-1].value

            player,computer = sel_val()
            pcount,ccount = 0,0

            pllst = []
            cmplst = []
            dec = Deck()

            while True:
                try:
                    pcount += game(pllst,dec)
                    if pcount == player:
                        print(f'You Won!!!!')
                        break
                    ccount += game(cmplst,dec)
                    if ccount == computer:
                        print(f'You Lost, computer number was {computer}')
                        break

                except Exception:
                    print('It was a tie')
                    if pcount > ccount:
                        print(f'You won by tiebreaker, your score {pcount} was \
            higher than computer {ccount}')
                    else:
                        print(f'You lost by tiebreaker, your score {pcount} was \
            lower than computer {ccount}')
                    break
                #____________________________________________________________________________________________________________________
        elif gmred==5:
            #program for chess segment
            print('NOTE: enter the valuses in format a2 a4')
            import sys
            import itertools
            WHITE = "white"
            BLACK = "black"

            class Game:
                def __init__(self):
                    self.playersturn = WHITE
                    self.message = "this is where prompts will go"
                    self.gameboard = {}
                    self.placePieces()
                    print("chess program. enter moves in algebraic notation separated by space. enter 'exit' to quit.")
                    self.main()

                    
                def placePieces(self):

                    for i in range(0,8):
                        self.gameboard[(i,1)] = Pawn(WHITE,uniDict[WHITE][Pawn],1)
                        self.gameboard[(i,6)] = Pawn(BLACK,uniDict[BLACK][Pawn],-1)
                        
                    placers = [Rook,Knight,Bishop,Queen,King,Bishop,Knight,Rook]
                    
                    for i in range(0,8):
                        self.gameboard[(i,0)] = placers[i](WHITE,uniDict[WHITE][placers[i]])
                        self.gameboard[(i,7)] = placers[i](BLACK,uniDict[BLACK][placers[i]])
                    placers.reverse()

                    
                def main(self):
                    
                    while True:
                        self.printBoard()
                        print(self.message)
                        self.message = ""
                        startpos,endpos = self.parseInput()
                        try:
                            target = self.gameboard[startpos]
                        except:
                            self.message = "could not find piece; index probably out of range"
                            target = None
                            
                        if target:
                            print("found "+str(target))
                            if target.Color != self.playersturn:
                                self.message = "you aren't allowed to move that piece this turn"
                                continue
                            if target.isValid(startpos,endpos,target.Color,self.gameboard):
                                self.message = "that is a valid move"
                                self.gameboard[endpos] = self.gameboard[startpos]
                                del self.gameboard[startpos]
                                self.isCheck()
                                if self.playersturn == BLACK:
                                    self.playersturn = WHITE
                                else : self.playersturn = BLACK
                            else : 
                                self.message = "invalid move" + str(target.availableMoves(startpos[0],startpos[1],self.gameboard))
                                print(target.availableMoves(startpos[0],startpos[1],self.gameboard))
                        else : self.message = "there is no piece in that space"
                                
                def isCheck(self):
                    king = King
                    kingDict = {}
                    pieceDict = {BLACK : [], WHITE : []}
                    for position,piece in self.gameboard.items():
                        if type(piece) == King:
                            kingDict[piece.Color] = position
                        print(piece)
                        pieceDict[piece.Color].append((piece,position))
                    #white
                    if self.canSeeKing(kingDict[WHITE],pieceDict[BLACK]):
                        self.message = "White player is in check"
                    if self.canSeeKing(kingDict[BLACK],pieceDict[WHITE]):
                        self.message = "Black player is in check"
                    
                    
                def canSeeKing(self,kingpos,piecelist):
                    for piece,position in piecelist:
                        if piece.isValid(position,kingpos,piece.Color,self.gameboard):
                            return True
                            
                def parseInput(self):
                    k=input()
                    if k=="exit":
                        sys.exit("Done")
                    try:
                        a,b = k.split()
                        print(a)
                        print(b)
                        if a!="exit":
                            ap = ((ord(a[0])-97), int(a[1])-1)
                            bp = (ord(b[0])-97, int(b[1])-1)
                        print(ap,bp)
                        return (ap,bp)
                    except:
                        print("error decoding input. please try again")
                        return((-1,-1),(-1,-1))
                
                """def validateInput(self, *kargs):
                    for arg in kargs:
                        if type(arg[0]) is not type(1) or type(arg[1]) is not type(1):
                            return False
                    return True"""
                    
                def printBoard(self):
                    print("  1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |")
                    for i in range(0,8):
                        print("-"*32)
                        print(chr(i+97),end="|")
                        for j in range(0,8):
                            item = self.gameboard.get((i,j)," ")
                            print(str(item)+' |', end = " ")
                        print()
                    print("-"*32)
                        
                       
                    
                """game class. contains the following members and methods:
                two arrays of pieces for each player
                8x8 piece array with references to these pieces
                a parse function, which turns the input from the user into a list of two tuples denoting start and end points
                a checkmateExists function which checks if either players are in checkmate
                a checkExists function which checks if either players are in check (woah, I just got that nonsequitur)
                a main loop, which takes input, runs it through the parser, asks the piece if the move is valid, and moves the piece if it is. if the move conflicts with another piece, that piece is removed. ischeck(mate) is run, and if there is a checkmate, the game prints a message as to who wins
                """

            class Piece:
                
                def __init__(self,color,name):
                    self.name = name
                    self.position = None
                    self.Color = color
                def isValid(self,startpos,endpos,Color,gameboard):
                    if endpos in self.availableMoves(startpos[0],startpos[1],gameboard, Color = Color):
                        return True
                    return False
                def __repr__(self):
                    return self.name
                
                def __str__(self):
                    return self.name
                
                def availableMoves(self,x,y,gameboard):
                    print("ERROR: no movement for base class")
                    
                def AdNauseum(self,x,y,gameboard, Color, intervals):
                    """repeats the given interval until another piece is run into. 
                    if that piece is not of the same color, that square is added and
                     then the list is returned"""
                    answers = []
                    for xint,yint in intervals:
                        xtemp,ytemp = x+xint,y+yint
                        while self.isInBounds(xtemp,ytemp):
                            target = gameboard.get((xtemp,ytemp),None)
                            if target is None: answers.append((xtemp,ytemp))
                            elif target.Color != Color: 
                                answers.append((xtemp,ytemp))
                                break
                            else:
                                break
                            
                            xtemp,ytemp = xtemp + xint,ytemp + yint
                    return answers
                            
                def isInBounds(self,x,y):
                    "checks if a position is on the board"
                    if x >= 0 and x < 8 and y >= 0 and y < 8:
                        return True
                    return False
                
                def noConflict(self,gameboard,initialColor,x,y):
                    "checks if a single position poses no conflict to the rules of chess"
                    if self.isInBounds(x,y) and (((x,y) not in gameboard) or gameboard[(x,y)].Color != initialColor) : return True
                    return False
                    
                    
            chessCardinals = [(1,0),(0,1),(-1,0),(0,-1)]
            chessDiagonals = [(1,1),(-1,1),(1,-1),(-1,-1)]

            def knightList(x,y,int1,int2):
                """sepcifically for the rook, permutes the values needed around a position for noConflict tests"""
                return [(x+int1,y+int2),(x-int1,y+int2),(x+int1,y-int2),(x-int1,y-int2),(x+int2,y+int1),(x-int2,y+int1),(x+int2,y-int1),(x-int2,y-int1)]
            def kingList(x,y):
                return [(x+1,y),(x+1,y+1),(x+1,y-1),(x,y+1),(x,y-1),(x-1,y),(x-1,y+1),(x-1,y-1)]



            class Knight(Piece):
                def availableMoves(self,x,y,gameboard, Color = None):
                    if Color is None : Color = self.Color
                    return [(xx,yy) for xx,yy in knightList(x,y,2,1) if self.noConflict(gameboard, Color, xx, yy)]
                    
            class Rook(Piece):
                def availableMoves(self,x,y,gameboard ,Color = None):
                    if Color is None : Color = self.Color
                    return self.AdNauseum(x, y, gameboard, Color, chessCardinals)
                    
            class Bishop(Piece):
                def availableMoves(self,x,y,gameboard, Color = None):
                    if Color is None : Color = self.Color
                    return self.AdNauseum(x, y, gameboard, Color, chessDiagonals)
                    
            class Queen(Piece):
                def availableMoves(self,x,y,gameboard, Color = None):
                    if Color is None : Color = self.Color
                    return self.AdNauseum(x, y, gameboard, Color, chessCardinals+chessDiagonals)
                    
            class King(Piece):
                def availableMoves(self,x,y,gameboard, Color = None):
                    if Color is None : Color = self.Color
                    return [(xx,yy) for xx,yy in kingList(x,y) if self.noConflict(gameboard, Color, xx, yy)]
                    
            class Pawn(Piece):
                def __init__(self,color,name,direction):
                    self.name = name
                    self.Color = color
                    self.direction = direction
                def availableMoves(self,x,y,gameboard, Color = None):
                    if Color is None : Color = self.Color
                    answers = []
                    if (x+1,y+self.direction) in gameboard and self.noConflict(gameboard, Color, x+1, y+self.direction) : answers.append((x+1,y+self.direction))
                    if (x-1,y+self.direction) in gameboard and self.noConflict(gameboard, Color, x-1, y+self.direction) : answers.append((x-1,y+self.direction))
                    if (x,y+self.direction) not in gameboard and Color == self.Color : answers.append((x,y+self.direction))
                    if (x,y+self.direction*2) not in gameboard and (x,y+self.direction) not in gameboard and Color == self.Color and y+self.direction+1 not in [0,7]:
                        answers.append((x,y+self.direction*2))
                    return answers

            """uniDict = {WHITE : {Pawn : "♙", Rook : "♖", Knight : "♘", Bishop : "♗", King : "♔", Queen : "♕" }, BLACK : {Pawn : "♟", Rook : "♜", Knight : "♞", Bishop : "♝", King : "♚", Queen : "♛" }}"""
            uniDict = {WHITE : {Pawn : "P", Rook : "R", Knight : "N", Bishop : "B", King : "K", Queen : "Q" }, BLACK : {Pawn : "p", Rook : "r", Knight : "n", Bishop : "b", King : "k", Queen : "q" }}
                    

                    


            Game()
            #___________________________________________________________________________________________________________________________
        elif gmred==6:
            theBoard = {'7': ' ' , '8': ' ' , '9': ' ' ,
                        '4': ' ' , '5': ' ' , '6': ' ' ,
                        '1': ' ' , '2': ' ' , '3': ' ' }

            board_keys = []

            for key in theBoard:
                board_keys.append(key)

            ''' We will have to print the updated board after every move in the game and 
                thus we will make a function in which we'll define the printBoard function
                so that we can easily print the board everytime by calling this function. '''

            def printBoard(board):
                print(board['7'] + '|' + board['8'] + '|' + board['9'])
                print('-+-+-')
                print(board['4'] + '|' + board['5'] + '|' + board['6'])
                print('-+-+-')
                print(board['1'] + '|' + board['2'] + '|' + board['3'])
            def game():

                turn = 'X'
                count = 0


                for i in range(10):
                    printBoard(theBoard)
                    print("It's your turn," + turn + ".Move to which place?")

                    move = input()        

                    if theBoard[move] == ' ':
                        theBoard[move] = turn
                        count += 1
                    else:
                        print("That place is already filled.\nMove to which place?")
                        continue 
                    if count >= 5:
                        if theBoard['7'] == theBoard['8'] == theBoard['9'] != ' ': # across the top
                            printBoard(theBoard)
                            print("\nGame Over.\n")                
                            print(" **** " +turn + " won. ****")                
                            break
                        elif theBoard['4'] == theBoard['5'] == theBoard['6'] != ' ': # across the middle
                            printBoard(theBoard)
                            print("\nGame Over.\n")                
                            print(" **** " +turn + " won. ****")
                            break
                        elif theBoard['1'] == theBoard['2'] == theBoard['3'] != ' ': # across the bottom
                            printBoard(theBoard)
                            print("\nGame Over.\n")                
                            print(" **** " +turn + " won. ****")
                            break
                        elif theBoard['1'] == theBoard['4'] == theBoard['7'] != ' ': # down the left side
                            printBoard(theBoard)
                            print("\nGame Over.\n")                
                            print(" **** " +turn + " won. ****")
                            break
                        elif theBoard['2'] == theBoard['5'] == theBoard['8'] != ' ': # down the middle
                            printBoard(theBoard)
                            print("\nGame Over.\n")                
                            print(" **** " +turn + " won. ****")
                            break
                        elif theBoard['3'] == theBoard['6'] == theBoard['9'] != ' ': # down the right side
                            printBoard(theBoard)
                            print("\nGame Over.\n")                
                            print(" **** " +turn + " won. ****")
                            break 
                        elif theBoard['7'] == theBoard['5'] == theBoard['3'] != ' ': # diagonal
                            printBoard(theBoard)
                            print("\nGame Over.\n")                
                            print(" **** " +turn + " won. ****")
                            break
                        elif theBoard['1'] == theBoard['5'] == theBoard['9'] != ' ': # diagonal
                            printBoard(theBoard)
                            print("\nGame Over.\n")                
                            print(" **** " +turn + " won. ****")
                            break 
                    if count == 9:
                        print("\nGame Over.\n")                
                        print("It's a Tie!!")
                    if turn =='X':
                        turn = 'O'
                    else:
                        turn = 'X'
                restart = input("Do want to play Again?(y/n)")
                if restart == "y" or restart == "Y":  
                    for key in board_keys:
                        theBoard[key] = " "

                    game()

            if __name__ == "__main__":
                game()
                #__________________________________________________________________________________________________________________
        elif gmred==7:
            from random import randint
            import itertools
            import logging
            import time


            def play_minesweeper():
                minefield_rows = 4
                minefield_columns = 4
                mine_row_index = randint(0, minefield_rows - 1)
                mine_column_index = randint(0, minefield_columns - 1)

                def find_ones_possible_indices(mine_index, minefield_length):
                    """
                    Finds all possible indices of 1s that surround mine
                    Function only works under assumption that minefield is square (all sides equal)
                    :param mine_index: index of the mine for its corresponding row or column
                    :param minefield_length: count of squares along one edge of minefield
                    :return: one_indices
                    """
                    one_indices = []
                    if mine_index == minefield_length - 1:
                        for one_index in range(mine_index - 1, mine_index + 1):
                            one_indices.append(one_index)
                    elif mine_index == 0:
                        for one_index in range(mine_index, mine_index + 2):
                            one_indices.append(one_index)
                    else:
                        for one_index in range(mine_index - 1, mine_index + 2):
                            one_indices.append(one_index)
                    return one_indices

                row_ones_indices = find_ones_possible_indices(mine_row_index, minefield_rows)
                column_ones_indices = find_ones_possible_indices(mine_column_index, minefield_columns)
                coordinate_indices_lists = [row_ones_indices, column_ones_indices]
                ones_coordinates = []
                for coordinate in itertools.product(*coordinate_indices_lists):
                    ones_coordinates.append(coordinate)
                hidden_minefield = [[] for _ in range(minefield_rows)]
                count_ones_and_zeros = 0
                for row_index in range(minefield_rows):
                    for column_index in range(minefield_columns):

                        # check if this value on the hidden_minefield is the value of the mine
                        if (row_index, column_index) == (mine_row_index, mine_column_index):
                            hidden_minefield[row_index].append(9)

                        # check if this value on the hidden_minefield is in the ones_coordinates list
                        elif (row_index, column_index) in ones_coordinates:
                            hidden_minefield[row_index].append(1)
                            count_ones_and_zeros += 1

                        # the value is not the mine or adjacent to the mine
                        else:
                            hidden_minefield[row_index].append(0)
                            count_ones_and_zeros += 1
                for row in hidden_minefield:
                    user_interface_minefield = [[] for _ in range(minefield_rows)]
                for empty_list in user_interface_minefield:
                    for i in range(minefield_columns):
                        empty_list.append('?')
                time.sleep(0.5)

                print("Time for the user to play! Try to avoid the mines!")
                # only enough guesses for user to guess all 1s and 0s; otherwise, user guesses mine and game ends
                for guess_counter, guess in enumerate(range(count_ones_and_zeros)):
                    print("\nIn minefield, row values start at 1 and go to {0}.".format(minefield_rows))
                    print("In minefield, column values start at 1 and go to {0}.".format(minefield_columns))
                    print("\nThis is the user_interface_minefield:")
                    for row in user_interface_minefield:
                        print(row)
                    def get_player_input():
                        guess_row = int(input("Guess row: "))
                        guess_column = int(input("Guess column: "))
                        return guess_row, guess_column

                    guess_row, guess_column = get_player_input()

                    def check_condition_guess(guess_index, minefield_edge_size):
                        if isinstance(guess_row, int) is False:
                            print("You didn't guess an integer")
                            bad_guess_status = True
                        elif guess_index < 1 or guess_index > minefield_edge_size:
                            print("Your guess integer is out of range of 1-4")
                            bad_guess_status = True
                        else:
                            bad_guess_status = False
                        return bad_guess_status

                    bad_guess_status = check_condition_guess(guess_row, minefield_rows)
                    bad_guess_status = check_condition_guess(guess_column, minefield_columns)

                    if bad_guess_status is True:
                        print("Please make a more appropriate guess")
                        continue
               
                    print("Your guessed coordinate: ({0}, {1})".format(guess_row, guess_column))

                    # create new variables for offsets of 1 less than guesses because we use zero-based numbering in Python
                    user_guess_row_offset = guess_row - 1
                    user_guess_column_offset = guess_column - 1

                    # make reveal of board and notify user with text change
                    if hidden_minefield[user_guess_row_offset][user_guess_column_offset] == 1:
                        print("You guessed a 1 so you're nearby a mine.")
                        user_interface_minefield[user_guess_row_offset][user_guess_column_offset] = '1'

                    elif hidden_minefield[user_guess_row_offset][user_guess_column_offset] == 0:
                        print("You guessed far from a mine. You're ok!")
                        user_interface_minefield[user_guess_row_offset][user_guess_column_offset] = '0'

                    else:
                        print("You guessed the mine! You lose!\nHere's what the minefield looks like:")
                        for row in hidden_minefield:
                            print(row)
                        break

                    if guess_counter == 0:
                        print("You have made {0} guess".format(guess_counter+1))
                    else:
                        print("You have made {0} guesses".format(guess_counter + 1))

            play_minesweeper()
            #______________________________________________________________________________________________________________________
            #)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
            #_______________________________________________________________________________________________________________________

    elif prored==3 :
        cbred=int(input("1 for story maker, 2 for chat bot and 3 for riddle time"))
        if cbred==1:
            print("welcome to story maker, chose the type of movie you want to make below:")
            smred=int(input("1 of horror, 2 of crime thriller and 3 for fairy tale"))
            if smred==1:
                print("you have selected horror let us start writing, to make a story enter the following thing,")
                smha=input("enter the first name of the main character:")
                smhb=input("enter the last name of the main character :")
                smhc=input("enter an adjective to discribe the main character:")
                smhd=input("enter the first name of the second character:")
                smhe=input("enter the last name of the second character:")
                smhf=input("enter the relation between the main and second character:")
                smhg=input("enter a job:")
                smhh=input("enter a another job:")
                smhi=input("enter a another job:")
                smhj=input("enter an object:")
                smhk=input("enter an adjective for object:")
                smhl=input("enter the number between 2 and 400:")
                smhm=input("enter a location:")
                smhn=input("enter an adjective:")
                smho=input("enter an adjective:")
                smhp=input("enter an adjective:")
                smhq=input("enter a animal:")
                smhr=input("enter a animal:")
                smhs=input("enter a animal:")
                smht=input("enter Something a ghost might appear when photographed (e.g. distorted, upside-down, translucent):")
                smhu=input("enter a body part (plural):")
                smhv=input("enter a body part (plural):")
                smhw=input("enter a type of accident:")
                smhx=input("enter an adjective to discribe a place:")
                print("*"*75)
                print("                    The Curse of the ",smhk," ",smhj)
                print("                        A Horror Story")
                print("                           by ",name)
                print(" Whilst investigating the death of a local ",smhi,", a ",smhc," ",smhg," called ",smha," ",smhb," uncovers a")
                print(" legend about a supernaturally-cursed, ",smhk," ",smhj," circulating throughout ",smhm,".")
                print(" As soon as anyone uses the ",smhj,", he or she has exactly ",smhl," days left to live.")
                print(" ")
                print(" The doomed few appear to be ordinary people during day to day life, but when photographed,")
                print(" they look ",smht,". A marked person feels like a ",smhn," ",smhq," to touch.")
                print(" ")
                print(" ",smha," gets hold of the ",smhj,", refusing to believe the superstition.")
                print(" A collage of images flash into his mind: a ",smho," ",smhr," balancing on a ",smhp," ",smhi,",")
                print(" an old newspaper headline about a ",smhw," accident, a hooded ",smhs," ranting about ",smhu," and a")
                print(" drinking well located in a ",smhx," place.")
                print(" ")
                print(" When ",smha," notices his ",smhv," have ",smhq,"-like properties, he realises that the curse of the")
                print(" ",smhk," ",smhj," is true and calls in his ",smhf,", a ",smhh," called ",smhd," ",smhe,", to help.")
                print(" ")
                print(" ",smhd," examines the ",smhj," and willingly submits himself to the curse.")
                print(" He finds that the same visions flash before his eyes. He finds the ",smho," ",smhr," balancing")
                print(" on a ",smhp," ",smhi," particularly chilling. He joins the queue for a supernatural death.")
                print(" ")
                print(" ",smha," and ",smhd," pursue a quest to uncover the meaning of the visions,")
                print(" starting with a search for the hooded ",smhs,".")
                print(" Will they be able to stop the curse before their time is up?")
            elif smred==2:
                #_______________________________________________________________________________________________________________
                print("you have selected crime thriler let us start writing, to make a story enter the following thing,")
                smca=input("enter the detective's title:")
                smcb=input("enter the detective's first name:")
                smcc=input("enter the detective's last name:")
                smcd=input("enter the sidekick's title:")
                smce=input("enter the sidekick's first name:")
                smcf=input("enter the sidekick's last name:")
                smcg=input("enter the first name of A person the detective is fond of:")
                smch=input("enter the last name of A person the detective is fond of:")
                smci=input("enter Their relationship to the detective:")
                smcj=input("enter an adjective to describe somebody's physical appearance:")
                smck=input("Positive adjective to describe somebody's character:")
                smcl=input("Positive adjective to describe somebody's character:")
                smcm=input("Negative adjectives to describe somebody's character:")
                smcn=input("Negative adjectives to describe somebody's character:")
                smco=input("Negative adjectives to describe somebody's character:")
                smcp=input("An adjective that could describe an object:")
                smcq=input("A geographical location:")
                smcr=input("Something somebody might be passionate about:")
                smcs=input("A body part (plural):")
                smct=input("A weapon:")
                smcu=input("An object:")
                smcv=input("Something you can become addicted to:")
                smcw=input("Job:")
                smcx=input("Job:")
                print("*"*75)
                print("The Mangled ",smcs," ")
                print("Crime Thriller")
                print("by",name," ")
                print("Mangled ",smcs," have been turning up all over ",smcq," and the inhabitants are scared.")
                print("Ten murders in ten weeks, all committed with a ",smct,", and still nobody has a clue who the ",smcm," killer is.")
                print(" ")
                print(" ",smca," ",smcb," ",smcc," is a ",smcj," and ",smck," ",smcw," with a fondness for ",smcr,".")
                print("He doesn't know it yet but he is the only one who can stop the ",smcn," killer.")
                print(" ")
                print("When his ",smci,", ",smcg," ",smch,", is kidnapped, ",smca," ",smcc," finds himself thrown into")
                print("the centre of the investigation. His only clue is a ",smcp," ",smcu,".")
                print(" ")
                print("He enlists the help of a ",smcl," ",smcx," called ",smce," ",smcf,".")
                print(" ")
                print("Can ",smcf," help ",smcc," overcome his ",smcv," addiction and find the answers before the ",smco," killer")
                print("and his deadly ",smct," strike again?")
                print("*"*75)
            elif smred==3:
                #_______________________________________________________________________________________
                print("you have selected fairy tale let us start writing, to make a story enter the following thing,")
                smfa=input("enter the first name of hero(male child):")
                smfb=input("last name of hero:")
                smfc=input("An adjective to describe your hero (e.g. little, brave):")
                smfd=input("A type of animal (e.g. bear, pig):")
                smfe=input("An adjective describing the animal(s) in this story (e.g. hairy, scary)(Note: not one relating to size):")
                smff=input("The name of a forest, woodland or park nearby (e.g. Sherwood Forest):")
                smfg=input("The hero's favourite cuddly toy (e.g. Mr Teddy):")
                smfh=input("first name of a friend of family member of the hero:")
                smfi=input("last name of a friend of family member of the hero:")
                smfj=input("His or her relationship to the hero:")
                smfk=input("A colour (e.g. red, green):")
                smfl=input("An item of clothing, singular (e.g. skirt, dungarees):")
                smfm=input("A type of healthy vegetable, plural (e.g. carrots, cabbages):")
                smfn=input("unhealthy foods, plural (e.g. biscuits, crisps):")
                smfo=input("unhealthy foods, plural (e.g. biscuits, crisps):")
                smfp=input("unhealthy foods, plural (e.g. biscuits, crisps):")
                smfq=input("unhealthy foods, plural (e.g. biscuits, crisps):")
                smfr=input("unhealthy foods, plural (e.g. biscuits, crisps):")
                print("*"*75)
                print(" ",smfa," ",smfb," and the Three ",smfe," ",smfd,"s")
                print("A Fairy Tale")
                print("by ",name," ")
                print("Once upon a time there was a ",smfc," boy called ",smfa," ")
                print(" ",smfb,". He was on the way to see his ",smfj," ",smfh," ",smfi,",")
                print("when he decided to take a short cut through ",smff,".")
                print(" ")
                print("It wasn't long before ",smfa," got lost. He looked around, but")
                print("all he could see were trees. Nervously, he felt into his bag for")
                print("his favourite toy, ",smfg,", but ",smfg," was nowhere to be")
                print("found! ",smfa," began to panic. He felt sure he had packed")
                print(" ",smfg,". To make matters worse, he was starting to feel hungry.")
                print("Unexpectedly, he saw a ",smfe," ",smfd," dressed in a ",smfk," ")
                print(" ",smfl," disappearing into the trees.")
                print(" ")
                print(" How odd!thought ",smfa,".")
                print(" ")
                print("For the want of anything better to do, he decided to follow")
                print("the peculiarly dressed ",smfd,". Perhaps it could tell him the")
                print("way out of the forest.")
                print(" ")
                print("Eventually, ",smfa," reached a clearing. He found himself")
                print("surrounded by houses made from different sorts of food.")
                print("There was a house made from ",smfm,", a house made from")
                print(" ",smfn,", a house made from ",smfo," and a house made from ",smfp,".")
                print(" ")
                print(" ",smfa," could feel his tummy rumbling. Looking at the houses")
                print("did nothing to ease his hunger.")
                print(" ")
                print("Hello! he called. Is anybody there?")
                print(" ")
                print("nobody replied")
                print(" ")
                print(" ",smfa," looked at the roof on the closest house and")
                print("wondered if it would be rude to eat somebody else's")
                print("chimney. Obviously it would be impolite to eat a whole")
                print("house, but perhaps it would be considered acceptable to")
                print("nibble the odd fixture or lick the odd fitting, in a time of need.")
                print(" ")
                print("A cackle broke through the air, giving ",smfa," a fright. A witch")
                print("jumped into the space in front of the houses. She was")
                print("carrying a cage. In that cage was ",smfg,"!")
                print(" ")
                print(" ",smfg,"! shouted ",smfa,". He turned to the witch. That's my toy!")
                print(" ")
                print("The witch just shrugged.")
                print(" ")
                print("Give ",smfg," back! cried ",smfa,".")
                print(" ")
                print("Not on your nelly! said the witch.")
                print(" ")
                print("At least let ",smfg," out of that cage!")
                print("Before she could reply, three ",smfe," ",smfd,"s rushed in from")
                print("a footpath on the other side of the clearing. ",smfa," ")
                print("recognised the one in the ",smfk," ",smfl," that he'd seen")
                print("earlier. The witch seemed to recognise him too.")
                print(" ")
                print("Hello Big ",smfd," said the witch.")
                print("Good morning. The ",smfd," noticed ",smfg,". Who is this?")
                print("That's ",smfg,", explained the witch.")
                print("Ooh! ",smfg," would look lovely in my house. Give it to me! demanded the ",smfd,".")
                print("The witch shook her head. ",smfg," is staying with me.")
                print(" ")
                print("Um... Excuse me... ",smfa," interrupted. ",smfg," lives with me! And not in a cage!")
                print(" ")
                print("Big ",smfd," ignored him. Is there nothing you'll trade? he asked the witch.")
                print(" The witch thought for a moment, then said, I do like to be")
                print("entertained. I'll release him to anybody who can eat a whole front door.")
                print(" ")
                print(" Big ",smfd," looked at the house made from ",smfp," and said,")
                print("No problem, I could eat an entire house made from ",smfp," if I wanted to.")
                print("That's nothing, said the next ",smfd,". I could eat two houses.")
                print("There's no need to show off, said the witch. Just eat one front door and I'll let you have ",smfg,".")
                print(" ")
                print(" ",smfa," watched, feeling very worried. He didn't want the")
                print("witch to give ",smfg," to Big ",smfd,". He didn't think ",smfg," ")
                print("would like living with a ",smfe," ",smfd,", away from his house and all his other toys.")
                print(" ")
                print("The other two ",smfd,"s watched while Big ",smfd," put on his")
                print("bib and withdrew a knife and fork from his pocket.")
                print("I'll eat this whole house, said Big ",smfd,". Just you watch!")
                print(" ")
                print("Big ",smfd," pulled off a corner of the front door of the house")
                print("made from ",smfn,". He gulped it down smiling, and went back for more.")
                print(" ")
                print("  And more.")
                print(" ")
                print("    And more.")
                print(" ")
                print("Eventually, Big ",smfd," started to get bigger - just a little bit")
                print("bigger at first. But after a few more fork-fulls of ",smfn,", he")
                print("grew to the size of a large snowball - and he was every bit as round.")
                print(" ")
                print("Erm... I don't feel too good, said Big ",smfd,".")
                print(" ")
                print("Suddenly, he started to roll. He'd grown so round that he could no longer balance!")
                print(" ")
                print("Help! he cried, as he rolled off down a slope into the forest.")
                print(" ")
                print("Big ",smfd," never finished eating the front door made from")
                print(" ",smfn," and ",smfg," remained trapped in the witch's cage.")
                print(" ")
                print("Average ",smfd," stepped up, and approached the house made from ",smfo,".")
                print(" ")
                print("I'll eat this whole house, said Average ",smfd,". Just you watch!")
                print("Average ",smfd," pulled off a corner of the front door of the")
                print("house made from ",smfo,". She gulped it down smiling, and went back for more. ")
                print(" ")
                print("   And more.")
                print(" ")
                print("     And more.")
                print("""After a while, Average """,smfd,""" started to look a little queasy. She grew greener...

   ...and greener.

A woodcutter walked into the clearing. "What's this bush doing here?" he asked.

"I'm not a bush, I'm a """,smfd,"""!" said Average """,smfd,""".

"It talks!" exclaimed the woodcutter. "Those talking bushes are the worst kind.
I'd better take it away before somebody gets hurt."

"No! Wait!" cried Average """,smfd,""", as the woodcutter picked her up.
But the woodcutter ignored her cries and
carried the """,smfd,""" away under his arm.

Average """,smfd,""" never finished eating the front door made from """,smfo,""" and
""",smfg,""" remained trapped in the witch's cage.

Little """,smfd,""" stepped up, and approached the house made from """,smfp,""".
"I'll eat this whole house," said Little """,smfd,""". "Just you watch!"

Little """,smfd,"""pulled off a corner of the front door of the house made from
""",smfp,""". He gulped it down smiling, and went back for more.

   And more.

      And more.

After five or six platefuls, Little """,smfd,""" started to fidget uncomfortably on the spot.

He stopped eating """,smfp,""" for a moment, then grabbed another forkful.

But before he could eat it, there came an almighty roar. A bottom burp louder than
a rocket taking off, propelled Little """,smfd,""" into the sky.

"Aggghhhhhh!" cried Little """,smfd,""". "I'm scared of heigh..."

Little """,smfd,""" was never seen again.

Little """,smfd,""" never finished eating the front door made from """,smfp,""" and
""",smfg,""" remained trapped in the witch's cage.

"That's it," said the witch. "I win. I get to keep """,smfg,"""."

"Not so fast," said """,smfa,""". "There is still one front door to go.
The front door of the house made from """,smfm,""". And I haven't had a turn yet.

"I don't have to give you a turn!" laughed the witch. "My game. My rules."

The woodcutter's voice carried through the forest. "I think you should give him a chance. It's only fair."

"Fine," said the witch. "But you saw what happened to the """,smfd,"""s. He won't last long."

"I'll be right back," said """,smfa,""".

"What?" said the witch. "Where's your sense of impatience? I thought you wanted """,smfg,""" back."

""",smfa,""" ignored the witch and gathered a hefty pile of sticks.
He came back to the clearing and started a small camp fire. Carefully, he broke off a piece of the door of the house made from """,smfm,""" and toasted it over the fire. Once it had cooked and cooled just a little, he took a bite. He quickly devoured the whole piece.

""",smfa,""" sat down on a nearby log.

"You fail!" cackled the witch. "You were supposed to eat the whole door."

"I haven't finished," explained """,smfa,""". "I am just waiting for my food to go down."

When """,smfa,"""'s food had digested, he broke off another piece of the door made from
""",smfm,""". Once more, he toasted his food over the fire and waited for it to cool just
a little. He ate it at a leisurely pace then waited for it to digest.

Eventually, after several sittings, """,smfa,""" was down to the final piece of the door
made from """,smfm,""". Carefully, he toasted it and allowed it to cool just a little.
He finished his final course. """,smfa,""" had eaten the entire front door of the house made from """,smfm,""".

The witch stamped her foot angrily. "You must have tricked me!" she said. "I don't reward cheating!"

"I don't think so!" said a voice. It was the woodcutter. He walked back into the clearing, carrying his axe.
"This little boy won fair and square. Now hand over """,smfg,""" or I will chop your broomstick in half."

The witch looked horrified. She grabbed her broomstick and placed it behind her. Then, huffing,
she opened the door of the cage.

""",smfa,""" hurried over and grabbed """,smfg,""", checking that his favourite toy was all right.
Fortunately, """,smfg,""" was unharmed.

""",smfa,""" thanked the woodcutter, grabbed a quick souvenir, and hurried on to meet """,smfh,""".
It was starting to get dark.

When """,smfa,""" got to """,smfh,"""'s house, his """,smfj,""" threw his arms around him.

"I was so worried!" cried """,smfh,""". "You are very late."

As """,smfa,""" described his day, he could tell that """,smfh,""" didn't believe him.
So he grabbed a napkin from his pocket.

"What's that?" asked """,smfh,""".

""",smfa,""" unwrapped a doorknob made from """,smfn,""". "Pudding!" he said.

""",smfh,""" almost fell off his chair.

The End""")
                
#________________________________________________________________________________________________________________________________________
        elif cbred==2:
            from random import randint
            print("*"*75)
            print("Hi, lets have a little chat.")
            print("whenever you are bored you can type 'q'to quit")
            cba=("how are you?","what's up??","how are you doing today??")
            cbb = cba[randint(0,2)]
            diyj=input("your answer")
            print(cbb)
            cbc="c"
            while cbc=="c":
                cbd=["could you live without the internet??  ","what would your perfect day be like??","When Are You Happiest?","What’s On Your Bucket List?","What’s The Best Comedy Movie You’ve Ever Seen?","What’s Your Favorite Song And Why This Particular One?","If You Were Stranded On A Deserted Island And You Could Have Only 1 Item, What Would It Be?"," What’s The Most Useful Thing You Own?","If You Had To Describe Yourself In Five Words, What Would They Be?","what are you most passionate about?","What makes you laugh out loud?","What is your favorite book?","What's something not many people know about you?","What was your favorite thing to do as a kid?","What are you doing this weekend?","Who is your role model?","What’s your biggest regret?","What job did you want to do when you were a kid?"]
                cbe = cbd[randint(0,17)]
                ccc=["oh yeahʕ￫ᴥ￩　ʔ","yup,same here(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","interesting ( ͡◉ ͜ʖ ͡◉)","true,me too  ( ͡°👅 ͡°)"]
                cbg = ccc[randint(0,4)]
                print(cbe)
                cbh=input("your answer=")
                print(cbg)
                if cbh=="q":
                    cbc="q"

                #____________________________________________________________________________________________________________________
        elif cbred==3:
            from random import randint
            cbcont="y"
            print("hi",name,",it is time for some riddles!!!")
            print("rules are as follows:-")
            print("1). enter only the main word of the answer(eg.'the egg' is wrong but 'egg is right)")
            print("2). all inputs in small letters")
            print("3). no cheating")
            print("4). have fun")
            while cbcont=="y":
                ranum=randint(0,25)
                if ranum==0:
                    print("the question is as belows:")
                    rque=input("What has to be broken before you can use it?")
                    rans="egg"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==1:
                    print("the question is as belows:")
                    rque=input(" I’m tall when I’m young, and I’m short when I’m old. What am I?")
                    rans="candle"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==2:
                    print("the question is as belows:")
                    rque=input("What month of the year has 28 days?")
                    rans="all"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==3:
                    print("the question is as belows:")
                    rque=input("What is full of holes but still holds water?")
                    rans="sponge"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==4:
                    print("the question is as belows:")
                    rque=input("What is always in front of you but can’t be seen?")
                    rans="future"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==5:
                    print("the question is as belows:")
                    rque=input(" What can you break, even if you never pick it up or touch it?")
                    rans="promise"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==6:
                    print("the question is as belows:")
                    rque=input("What goes up but never comes down?")
                    rans="age"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==7:
                    print("the question is as belows:")
                    rque=input(" What gets wet while drying?")
                    rans="towel"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==8:
                    print("the question is as belows:")
                    rque=input("I shave every day, but my beard stays the same. What am I?")
                    rans="barber"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==9:
                    print("the question is as belows:")
                    rque=input("")
                    rans=""
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==10:
                    print("the question is as belows:")
                    rque=input("You walk into a room that contains a match, a kerosene lamp, a candle and a fireplace. What would you light first?")
                    rans="match"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==11:
                    print("the question is as belows:")
                    rque=input("What can’t talk but will reply when spoken to?")
                    rans="An echo"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==12:
                    print("the question is as belows:")
                    rque=input("The more of this there is, the less you see. What is it?")
                    rans="Darkness"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==13:
                    print("the question is as belows:")
                    rque=input("What has lots of eyes, but can’t see?")
                    rans="potato"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==14:
                    print("the question is as belows:")
                    rque=input("What has one eye, but can’t see?")
                    rans="needle"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==15:
                    print("the question is as belows:")
                    rque=input("What has hands, but can’t clap?")
                    rans="clock"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==16:
                    print("the question is as belows:")
                    rque=input("What has legs, but doesn’t walk?")
                    rans="table"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==17:
                    print("the question is as belows:")
                    rque=input("What has one head, one foot and four legs?")
                    rans="bed"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==18:
                    print("the question is as belows:")
                    rque=input("What can you catch, but not throw?")
                    rans="cold"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==19:
                    print("the question is as belows:")
                    rque=input("What has many teeth, but can’t bite?")
                    rans="comb"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==20:
                    print("the question is as belows:")
                    rque=input(" What has words, but never speaks?")
                    rans="book"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==21:
                    print("the question is as belows:")
                    rque=input("What has a head and a tail but no body?")
                    rans="coin"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==22:
                    print("the question is as belows:")
                    rque=input("I am an odd number. Take away a letter and I become even. What number am I?")
                    rans="seven"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==23:
                    print("the question is as belows:")
                    rque=input("If two’s company, and three’s a crowd, what are four and five?")
                    rans="nine"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==24:
                    print("the question is as belows:")
                    rque=input("What five-letter word becomes shorter when you add two letters to it?")
                    rans="short"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")
                elif ranum==25:
                    print("the question is as belows:")
                    rque=input("What is so fragile that saying its name breaks it?")
                    rans="silence"
                    if rque==rans:
                        ccc=["correctʕ￫ᴥ￩　ʔ","true(๑￫ܫ￩)","absolutlyʕ⊙ᴥ⊙ʔ","amazing ( ͡◉ ͜ʖ ͡◉)","outstanding  ( ͡°👅 ͡°)"]
                        cbg = ccc[randint(0,4)]
                        print(cbg)
                    elif rque!=rans:
                        cccr=["oopsʕ￫ᴥ￩　ʔ","wrong(๑￫ܫ￩)","better luck next timeʕ⊙ᴥ⊙ʔ","nada ( ͡◉ ͜ʖ ͡◉)","incorrect ( ͡°👅 ͡°)"]
                        cbgr = cccr[randint(0,4)]
                        print(cbgr)
                        print("the correct answer is :-",rans)
                    cbcont=input("do you want to continue (y/n)")

                #________________________________________________________________________________________________________________________
                #)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
                #_____________________________________________________________________________________________________________________
    elif prored==4:
        import calendar

        yy = int(input("Enter year: "))
        mm = int(input("Enter month: "))
        print(calendar.month(yy, mm))
        #___________________________________________________________________________________________________________
        #)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
        #____________________________________________________________________________________________________________
    elif prored==5:
        print("Do you want to view, add or delete from your task list")

        n = "y"

        while n == "y":

            a = int(input('''
        For view, 1
        For add, 2
        For delete, 3:- '''))

            if a == 1:
                file = open("task_list.txt", "r")
                str = file.read()
                print(str)
                file.close()

            if a == 2:
                file = open("task_list.txt", "w+")
                n = "y"
                lst = []
                while n == "y":
                    print('')
                    name = input("Enter name of event:- ")
                    s_time = input("Enter start time of event:- ")
                    e_time = input("Enter end time of event:- ")
                    lst.append(name + " :- " + s_time + " - " + e_time + '\n')
                    print("")
                    n = input("Do you want to continue, write y for yes or n for no:- ")
                file.writelines(lst)

                file = open("task_list.txt", "r")
                str = file.read()
                print(str)
                file.close()

            if a == 3:
                file = open("task_list.txt", "r+")
                file.seek(0)
                file.truncate()
                print('')
                print("The data has been deleted:- ")
            print('')
            n = input("Do you want to continue to use our program, write y for yes or n for no:- ")

            if n == "n":
                print("")
                print("Thank you for using our program")


    else:
        print("*****ERROR*****")
        print("the above requrements are not met")
